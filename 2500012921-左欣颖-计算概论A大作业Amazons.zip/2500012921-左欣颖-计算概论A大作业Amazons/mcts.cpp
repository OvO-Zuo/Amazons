#include <bits/stdc++.h>
#include "cv.h"
#include "treenode.h"
#include "mcts.h"
#include "step.h"
#include "search.h"
#include "board.h"
#include "Amazons.h"

using namespace std;

MCT::MCT(double c) {
    n_const=c;
    time_limit=1.0;   
    if_search=true;
}

one_move MCT::MCT_search(const one_move& mv,int now_col) {
    move_from_fa=mv;
	//cout<<"turn "<<mv.now_turn<<endl;
    if(mv.now_turn!=no_lst) {
		//cout<<mv.from.x<<" "<<mv.from.y<<" "<<mv.to.x<<" "<<mv.to.y<<" "<<mv.set_b.x<<" "<<mv.set_b.y<<endl;
		make_move(A,mv); 
	}
	/*for(int i=0;i<8;i++) {
		for(int j=0;j<8;j++) cout<<A[i][j]<<" ";
		puts("");
	}
	system("pause");*/
    rt=std::make_shared<tree_node>(nullptr,A,mp.now_turn?white:black,n_const);
    
    decltype(rt) best_son;
    time(&start_time);
    for(;if_search;) {
        if(rt->full_expanded) { 
            best_son=best_child(rt);
            break;
        }
		//cout<<"wow\n";
        auto leaf=tree_policy(rt);
		//cout<<"end policy\n";
        int value=default_policy(leaf);
		//cout<<"end default\n";
        backtrack(leaf,value);
		//cout<<"end track\n";

        time(&end_time);
        if(difftime(end_time,start_time)>time_limit) break;
    }

    best_son=best_child(rt);
	/*cout<<now_col<<endl;
	for(int i=0;i<8;i++) {
		for(int j=0;j<8;j++) 
			if(best_son->A[i][j]==barrier) cout<<"BARRIER:"<<i<<" "<<j<<" "<<A[i][j]<<endl;
	}
	for(int i=0;i<8;i++,cout<<endl) {
		for(int j=0;j<8;j++) cout<<A[i][j]<<" ";
	}
	puts("");*/
    for(int i=0;i<8;++i)
        for(int j=0;j<8;++j) {
			if(A[i][j]!=barrier&&best_son->A[i][j]==barrier) 
                best_move.set_b.x=i,best_move.set_b.y=j;
            if(A[i][j]!=now_col&&best_son->A[i][j]==now_col)
                best_move.to.x=i,best_move.to.y=j;
            if(A[i][j]==now_col&&best_son->A[i][j]!=now_col)
                best_move.from.x=i,best_move.from.y=j;
        }
	/*cout<<best_move.set_b.x<<" "<<best_move.set_b.y<<endl;
	cout<<"nmmd\n";
	system("pause");*/
    rt.reset(); 
    best_move.now_turn=now_col;
    make_move(A,best_move);
    return best_move;
}

std::shared_ptr<tree_node>& MCT::best_child(std::shared_ptr<tree_node>&node) {
	int mx;
	int len=node->child_node.size();
    for(int i=0;i<len;++i) 
        if((node->child_node[i]->eval)>(node->child_node[mx]->eval)) mx=i;
    return node->child_node[mx];
}

std::shared_ptr<tree_node> MCT::tree_policy(std::shared_ptr<tree_node> node) {
    for(;check_state(node->A)==0;) {
        (node->num_visit)++;  
        if(!(node->not_use_node.empty())) {
            using type=std::vector<one_move>::size_type;
			int len=(node->not_use_node).size();
            len=rnd()%len;
            one_move mv=node->not_use_node[len];
            node->not_use_node.erase(node->not_use_node.begin()+len); 
            make_move(node->A,mv);
			
            node->child_node.emplace_back(std::make_shared<tree_node>(node,node->A,-(node->now_turn),node->nc));
            ++node_num;  
            withdraw_move(node->A,mv);
            return node->child_node.back();  
        } else if(node->child_node.empty()) {
            int num=step_creator->create_new_step(node->A,node->now_turn,node->not_use_node);
            if(num==0) { //��ֹ״̬
                node->full_expanded=true;  
                break;
            }
        } else {
            bool f=true;
            for(const auto &child:node->child_node)
                f=(f&&child->full_expanded);
            if(f) {  
                node->full_expanded=true;
                return node;
            }
            node=best_child(node);
        }
    }
    return node;
}

int MCT::default_policy(std::shared_ptr<tree_node> node) {
    if(node->full_expanded) return node->leaf_value;
    int board[8][8];
    memcpy(board,node->A,8*8*sizeof(int));
    
	std::vector<one_move> move_list;
    int res=check_state(board);
    if(res) node->full_expanded=true;
    int side=node->now_turn;
    using type=std::vector<one_move>::size_type;
    for(;res==empty;res=check_state(board),side=-side) {
        /*	int n=step_creator->create_new_step(board,side,move_list);
			n=rnd()%n;
			const one_move& mv=move_list[n];
			�����
		*/
		
        step_creator->create_new_step(board,side,move_list);
		const one_move& mv=choose_move(board,side,move_list);
		//---------------------------��Ȩ
		
		make_move(board,mv);
		/*for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) cout<<board[i][j]<<" ";
			cout<<endl;
		}
		cout<<"res:"<<res<<endl;*/
		
        move_list.clear();  // ���
    }
	/*for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) cout<<board[i][j]<<" ";
			cout<<endl;
		}
		cout<<"end res:"<<res<<endl;*/
    return res;
}

void MCT::backtrack(std::shared_ptr<tree_node>&node,int leaf_value){
    for(;node->fa_node.lock()!=nullptr;node=node->fa_node.lock(),leaf_value=-leaf_value) {
        node->Qsa=(leaf_value-(node->Qsa))/(node->num_visit);
        node->pu=node->Qsa+
                (node->nc)*
				std::sqrt(std::log(node->fa_node.lock()->num_visit)/(1+node->num_visit));
        node->leaf_value=leaf_value;
    }
}
/*
-1 2 0 0 0 0 0 0
0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0
0 2 -1 0 0 0 0 0
0 0 -1 0 0 0 0 0
-1 2 0 0 2 2 2 -1
2 0 0 0 -1 0 0 0
0 0 -1 0 2 0 2 -1
res:0
-1 2 0 0 0 2 0 0
0 0 0 0 -1 0 0 0
0 0 0 0 0 0 0 0
0 2 0 0 0 0 0 0
0 0 -1 0 0 0 0 0
-1 2 0 0 2 2 2 -1
2 0 0 0 -1 0 0 0
0 0 -1 0 2 0 2 -1
res:0
*/