#ifndef MCTS_H
#define MCTS_H

#include "search.h"
#include "treenode.h"
#include "chess.h"
#include "Amazons.h"

class MCT:public search,public Amazons {
public:
    MCT(double limit_c=sqrt(2));
    virtual ~MCT()=default;
    one_move MCT_search(const one_move& mv,int now_col);//GetBestMove
private:
    double time_limit; //搜索时间限制
    double n_const;// 扩展常数
    std::shared_ptr<tree_node> rt;
    one_move move_from_fa; // m_move
    time_t start_time;
    time_t end_time;

    std::shared_ptr<tree_node>& best_child(std::shared_ptr<tree_node> &node);//返回最佳孩子
    std::shared_ptr<tree_node> tree_policy(std::shared_ptr<tree_node> node);//返回最佳叶子或未经扩展的叶子
    int default_policy(std::shared_ptr<tree_node> node); //rollout
    void backtrack(std::shared_ptr<tree_node> &node,int leaf_value);//负极大 回溯 

};

#endif