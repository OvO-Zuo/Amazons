#include <bits/stdc++.h>
#include "cv.h"
#include "chess.h"
#include "check.h"
#include "step.h"
#include "board.h"
using namespace std;

vector<Step> step_stack; 
void withdraw(int n_step) {
	Step tmp;
	for(int cc=0;cc<n_step;cc++) {
		tmp=step_stack.back();
		step_stack.pop_back();
		if(tmp.now_type==0) {
			swap(mp.board[tmp.c_x][tmp.c_y],mp.board[tmp.p_x][tmp.p_y]);
		} else mp.board[tmp.c_x][tmp.c_y]=0;
	}
	system("cls");
	mp.show_board();
	cout<<"���سɹ�\n";
}
void push_move(int c_x,int c_y,int p_x,int p_y) {
	Step tmp;
	tmp.c_x=c_x,tmp.c_y=c_y;
	tmp.p_x=p_x,tmp.p_y=p_y;
	tmp.now_type=0;
	swap(mp.board[c_x][c_y],mp.board[p_x][p_y]);
	step_stack.emplace_back(tmp);
}
void push_set_barrier(int b_x,int b_y) {
	Step tmp;
	tmp.c_x=b_x,tmp.c_y=b_y;
	tmp.now_type=1;
	mp.board[b_x][b_y]=barrier;
	step_stack.emplace_back(tmp);
}

int game_step::create_new_step(int board[8][8],int side,
	std::vector<one_move> &move_list) {
	memcpy(nboard,board,8*8*sizeof(int));
	node_num=0;
	int i,j,k,l,t;
	for(i=0;i<8;i++) 
		for(j=0;j<8;j++) 
			if(board[i][j]==side) {
				for(t=0;t<8;t++) {
					k=i+bu[t][0];
					l=j+bu[t][1];
					for(;k>=0&&k<8&&l>=0&&l<8&&board[k][l]==0;) {
						create_barrier(i,j,k,l,side,move_list);
						k+=bu[t][0];
						l+=bu[t][1];
					}
				}
			}
	//cout<<move_list.size()<<endl;
	/*for(auto mv:move_list) {
		cout<<"mvv:"<<mv.set_b.x<<" "<<mv.set_b.y<<endl;
	}*/
	return node_num;
}
int game_step::check_game(int board[8][8],int side) {
	int num_b=0,num_w=0;// ���ܶ��ĺ�/������Ŀ
	int i,j,k,l,t;
	int cnt=0;//�˸���������ĸ���
	for(i=0;i<8;i++) 
		for(j=0;j<8;j++) 
			if(board[i][j]&&board[i][j]!=barrier) {
				cnt=0;
				for(t=0;t<8;t++) {
					k=i+bu[t][0];
					l=j+bu[t][1];
					if(k<0||k>=8||l<0||l>=8||board[k][l]) ++cnt;
				}
				if(cnt==8) board[i][j]==black?num_b++:num_w++;
				
			}
	if(side==black&&num_w==4) return black_win;
	else if(side==white&&num_b==4) return white_win;
	else return not_end;
}
void game_step::create_barrier(int fx,int fy,int tx,int ty,
	int side,std::vector<one_move> &move_list) {
	nboard[fx][fy]=0;
	nboard[tx][ty]=side;
	int nx=tx,ny=ty;
	int i;
	for(i=0;i<8;i++) {
		nx=tx+bu[i][0];
		ny=ty+bu[i][1];
		for(;nx>=0&&nx<8&&ny>=0&&ny<8&&nboard[nx][ny]==empty;) {
			one_move tmp;
			tmp.from=pos(fx,fy);
			tmp.to=pos(tx,ty);
			tmp.set_b=pos(nx,ny);
			tmp.now_turn=side;
			move_list.emplace_back(tmp);
			nx+=bu[i][0];
			ny+=bu[i][1];
			++node_num;
		}
	}
	//cout<<move_list.size()<<endl;
	/*for(auto mv:move_list) {
		cout<<"mvvc:"<<mv.set_b.x<<" "<<mv.set_b.y<<endl;
	}*/
	nboard[fx][fy]=side;
	nboard[tx][ty]=0;
}