#include "cv.h"
#include <random>
int game_type;
bool bot_first;
bool if_withdraw;
int Lx=-1,Ly=-1;
double d_inf=1e9;
double eps=1e-1;


//std::mt19937 rnd(chrono::system_clock::now().time_since_epoch().count());
std::mt19937 rng(0);
int rnd() { 
    return std::abs(static_cast<int>(rng())); 
}