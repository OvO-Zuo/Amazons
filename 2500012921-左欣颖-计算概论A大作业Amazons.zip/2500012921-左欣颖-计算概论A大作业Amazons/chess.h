#ifndef CHESS_H
#define CHESS_H

struct pos {
    int x,y;
    pos(int a=0,int b=0):x(a),y(b){}
};
struct one_move {
    pos from;
    pos to;
    pos set_b;
    int now_turn;//黑/白
    one_move(){};
    one_move (const one_move &mv) {
        from.x=mv.from.x;
        from.y=mv.from.y;
        to.x=mv.to.x;
        to.y=mv.to.y;
        set_b.x=mv.set_b.x;
        set_b.y=mv.set_b.y;
        now_turn=mv.now_turn;
    }
    void operator=(const one_move &mv) {
        from.x=mv.from.x;
        from.y=mv.from.y;
        to.x=mv.to.x;
        to.y=mv.to.y;
        set_b.x=mv.set_b.x;
        set_b.y=mv.set_b.y;
        now_turn=mv.now_turn;
    }
};


#endif