#ifndef Amazons_H
#define Amazons_H

#include "chess.h"
#include "step.h"
#include <vector>
#include <cstring>

// 距离缓存结构体
struct dis_cache {
    int queen_to_white[8][8];  // 皇后距离到白棋
    int queen_to_black[8][8];  // 皇后距离到黑棋
    int king_to_white[8][8];   // 国王距离到白棋
    int king_to_black[8][8];   // 国王距离到黑棋
    
    // 有效性标记
    bool valid[8][8];
    bool computed;
    int last_board_hash;
    
    dis_cache():computed(false),last_board_hash(0) {
        memset(queen_to_white,0x3f,8*8*sizeof(int));
        memset(queen_to_black,0x3f,8*8*sizeof(int));
        memset(king_to_white,0x3f,8*8*sizeof(int));
        memset(king_to_black,0x3f,8*8*sizeof(int));
        memset(valid,0,8*8*sizeof(bool));
    }
    
    void reset() {
        memset(queen_to_white,0x3f,8*8*sizeof(int));
        memset(queen_to_black,0x3f,8*8*sizeof(int));
        memset(king_to_white,0x3f,8*8*sizeof(int));
        memset(king_to_black,0x3f,8*8*sizeof(int));
        memset(valid,0,8*8*sizeof(bool));
        computed=false;
    }
};

class Amazons {
public:
    const one_move& choose_move(int board[8][8],int side,std::vector<one_move> &move_list);
protected:
    int Ab[8][8];
    int A_side;
    double w,c1,c2,t1,t2;
    dis_cache cache;
    
    struct move_cache {
        one_move move;
        int v;
        bool end_eval;//evaluated;
    };
    int quick_eval(one_move mv);
    void update_cache(one_move mv);
    int queen_distance(int x,int y,int col);
    int king_distance(int x,int y,int col);
    void mark_affected_positions(const one_move& mv, bool needs_update[8][8]);
    void mark_ray(int x, int y, int dir, bool needs_update[8][8]);
    void calc();                          
    void compute_all_distances();         
    void compute_d1(int col,int dis_array[8][8]);
    void compute_d2(int col,int dis_array[8][8]);
    int evaluate(one_move mv);  
    
    int compute_hash() const;
    bool if_recompute() const;
    
private:
    dis_cache cache_backup;
};

#endif