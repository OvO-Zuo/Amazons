#ifndef CHECK_H
#define CHECK_H
bool check_move(int fromX,int fromY,int toX,int toY);
#endif