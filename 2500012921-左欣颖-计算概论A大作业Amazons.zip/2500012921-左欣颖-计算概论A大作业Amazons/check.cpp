#include <bits/stdc++.h>
#include "cv.h"
#include "board.h"
using namespace std;

bool check_move(int from_x,int from_y,int to_x,int to_y) {
	//cout<<from_x<<" "<<from_y<<" "<<to_x<<" "<<to_y<<endl;
	if(from_x<0||from_x>7||from_y<0||from_y>7) return false;
	if(to_x<0||to_x>7||to_y<0||to_y>7) return false;
	if(to_x==from_x) {
		int mn,mx;
		mx=max(from_y,to_y),mn=min(from_y,to_y);
		for(int i=mn+(mn==from_y);i<=mx-(from_y==mx);i++)
			if(mp.board[to_x][i]) return false;
		return true;
	} 
	if(from_y==to_y) {
		int mn,mx;
		mx=max(from_x,to_x),mn=min(from_x,to_x);
		for(int i=mn+(mn==from_x);i<=mx-(mx==from_x);i++) {
			cout<<mp.board[i][to_y]<<endl;
			if(mp.board[i][to_y]) return false;
		}
		return true;
	}
	if(abs(from_x-to_x)==abs(from_y-to_y)) {
		int dx,dy;
		dx=(from_x<to_y?1:-1);
		dy=(from_y<to_y?1:-1);
		for(int i=from_x+dx,j=from_y+dy;i!=to_x&&j!=to_y;i+=dx,j+=dy)
			if(mp.board[i][j]) return false;
		return true;
	}	
	return false;
}
