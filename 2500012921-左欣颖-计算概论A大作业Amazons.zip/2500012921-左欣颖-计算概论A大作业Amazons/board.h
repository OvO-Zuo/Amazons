#ifndef BOARD_H
#define BOARD_H

#include <iostream>

class mBoard {
public:
    void show_board();
    void init_board();
    void read_board();
    int board[8][8];//棋盘
    int now_turn;//下一步走子方
    int now_type;//下一步应当 动棋子/放障碍
private:
    void file_out();
};
extern mBoard mp;
#endif