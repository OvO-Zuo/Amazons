#ifndef SEARCH_H
#define SEARCH_H

#include "chess.h"
#include "step.h"

class search {
public:
    search();
    virtual ~search();
    void pre_init(int board[8][8]);
    void init(){node_num=0;}
protected:
    void make_move(int board[8][8],const one_move &mv);
    void withdraw_move(int board[8][8],const one_move &mv);
    int check_state(int board[8][8]);

    int A[8][8];
    bool if_search;
    long long node_num;
    game_step *step_creator;
    one_move best_move;

};

#endif
