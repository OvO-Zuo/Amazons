#ifndef CV_H
#define CV_H

const int black=1;    // ����
const int white=-1;   // ����
const int barrier=2;  // �ϰ�
const int empty=0;
const int bu[8][2]={{-1,0},{-1,1},{0,1},{1,1},{1,0},{1,-1},{0,-1},{-1,-1}};
const int black_win=1;
const int white_win=0;
const int not_end=-1;
const int player=1;
const int bot=2;
const int no_lst=250;
const int player_type[4][2]={{1,1},{1,2},{2,1},{2,2}};
//���ˣ��˻������ˣ�����
extern bool if_withdraw;
extern int Lx,Ly;
extern int game_type;
extern bool bot_first;
extern double d_inf;
const int i_inf=1e9;
extern double eps;
const double inf=100000000000.0;

int rnd();

#endif // ����