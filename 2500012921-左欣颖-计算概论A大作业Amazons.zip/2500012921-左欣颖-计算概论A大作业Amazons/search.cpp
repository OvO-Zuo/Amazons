#include <bits/stdc++.h>
#include "cv.h"
#include "chess.h"
#include "step.h"
#include "search.h"


search::search()
{
    step_creator=new game_step;
    node_num=0;
    memset(A,0,sizeof(A));
	A[0][2]=black;
	A[2][0]=black;
	A[0][5]=black;
	A[2][7]=black;
	A[5][0]=white;
	A[7][2]=white;
	A[5][7]=white;
	A[7][5]=white;
}
void search::pre_init(int board[8][8]) {
	memcpy(A,board,8*8*sizeof(int));
}
search::~search(){
    if(step_creator!=nullptr){
        delete step_creator;
        delete step_creator;
    }
}

void search::make_move(int board[8][8],const one_move& mv){
    board[mv.from.x][mv.from.y]=empty;
    board[mv.to.x][mv.to.y]=mv.now_turn;
    board[mv.set_b.x][mv.set_b.y]=barrier;
}

void search::withdraw_move(int board[8][8],const one_move& mv){
    board[mv.set_b.x][mv.set_b.y]=empty;
    board[mv.to.x][mv.to.y]=empty;
    board[mv.from.x][mv.from.y]=mv.now_turn;
}

int search::check_state(int board[8][8]) {
    int num_b=0,num_w=0;
    for(int i=0;i<8;++i)
        for(int j=0;j<8;++j)
            if(board[i][j]==black||board[i][j]==white) {
                int cc=0;
                for(int k=0;k<8;++k) {
                    int nx=i+bu[k][0],ny=j+bu[k][1];
                    if(nx<0||nx>7||ny<0||ny>7||board[nx][ny]!=0) ++cc;
                }
                if(cc>=8) {  
                    if(board[i][j]==black) ++num_b;
                    else ++num_w;
                }
            }
	//std::cout<<num_b<<" "<<num_w<<"\n";	
    if(num_b>=4) return white;
    else if(num_w>=4) return black;
    else return 0;
}
