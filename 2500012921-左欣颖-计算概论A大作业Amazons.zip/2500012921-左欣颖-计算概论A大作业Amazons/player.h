#ifndef PLAYER_H
#define PLAYER_H
#include <bits/stdc++.h>
using namespace std;
#define pr4 pair<pair<pair<int,int>,int>,int>
#define pr pair<int,int>
void get_move();
pr4 player_move();
void get_set_barrier();
pr player_set_barrier();
#endif