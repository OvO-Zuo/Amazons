#include <bits/stdc++.h>
#include "Amazons.h"
#include "chess.h"
#include "cv.h"
using namespace std;

int Amazons::quick_eval(one_move mv) {
	swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
	Ab[mv.set_b.x][mv.set_b.y]=barrier;

    double total_score=0.0;
    int tdis=max(abs(2*mv.to.x-7),abs(2*mv.to.y-7));
    double center_score=(14.0-tdis)*0.1;
    bool is_in_corner=(mv.to.x<=1&&mv.to.y<=1)||(mv.to.x<=1&&mv.to.y>=6)||
                      (mv.to.x>=6&&mv.to.y<=1)||(mv.to.x>=6&&mv.to.y>=6);
    if(is_in_corner) center_score-=1.5;
    total_score+=center_score;
    
    int mobility=0;
    for(int dir=0;dir<8;dir++) {
        int nx=mv.to.x+bu[dir][0];
        int ny=mv.to.y+bu[dir][1];
        if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==empty) mobility++;
    }
    
    double mobility_score=0.0;
    if(mobility<=2) mobility_score=-3.0; 
    else if(mobility<=4) mobility_score=-1.0;
    else if (mobility >= 6) mobility_score=1.5;
    total_score+=mobility_score;
    
    double arrow_score=0.0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++) 
            if(Ab[i][j]==(A_side==black?white:black)) {
                int q_dis=max(abs(mv.set_b.x-i),abs(mv.set_b.y-j));
                if(q_dis<=2) arrow_score+=(3-q_dist)*0.4;
            }
    int make_link=0;
    for(int dir=0;dir<8;dir++) {
        int nx=mv.set_b.x+bu[dir][0];
        int ny=mv.set_b.y+bu[dir][1];
        if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==barrier) make_link++;
    }
    if(make_link>=2) arrow_score+=0.8;
    total_score+=arrow_score;
    
    int move_dis=max(abs(mv.to.x-mv.from.x),abs(mv.to.y-mv.from.y));
    double move_dis_score=0.0;
    if (move_dis==1) move_dis_score=-0.5;
    else if(move_dis>=2&&move_dis<=4) move_dis_score=1.0;
    else if(move_dis>=5) move_dis_score=0.5;
    total_score+=move_dis_score;
    
    double distribute_score=0.0;
    int avg_dis=0.0;
    for(int i=0;i<8;i++) 
        for(int j=0;j<8;j++) {
            if(Ab[i][j]==A_side&&!(i==mv.from.x&&j==mv.from.y)) {
                int dist=max(abs(mv.to.x-i),abs(mv.to.y-j));
                avg_dis+=dist;
            }
        }
    
    if(avg_dis<10) distribute_score=-1.0;
    else if(avg_dis>15) distribute_score=0.5;
    total_score+=distribute_score;
    
    double defense_score=0.0;
    for(int i=0;i<8;i++) 
        for(int j=0;j<8;j++) 
            if(Ab[i][j]==A_side&&!(i==mv.from.x&&j==mv.from.y)) {
                int num=0;
                for(int dir=0;dir<8;dir++) {
                    int nx=i+bu[dir][0];
                    int ny=j+bu[dir][1];
                    if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==empty) num++;
                }
                if(num<=2) defense_score-=2.0;
            }    
    total_score+=defense_score;
    
    int num_empty=0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            if(Ab[i][j]==empty) num_empty++;
    
    double endgame_factor=0.0;
    if(num_empty<24) {
        double territory_score=0.0;
        int my_near_bar=0;
        int oppo_near_bar=0;
        for(int dir=0;dir<8;dir++) {
            int nx=mv.set_b.x+bu[dir][0];
            int ny=mv.set_b.y+bu[dir][1];
            if(nx>=0&&nx<8&&ny>=0&&ny<8) {
                if(Ab[nx][ny]==A_side) my_near_bar++;
                else if(Ab[nx][ny]!=empty&&Ab[nx][ny]!=barrier) oppo_near_bar++;
            }
        }
        if(my_near_bar<oppo_near_bar) territory_score=0.8;
        else if(my_near_bar>oppo_near_bar) territory_score=-0.5;        
        endgame_factor=territory_score*(32-num_empty)/10.0;
    }
    total_score+=endgame_factor;
	
	swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
	Ab[mv.set_b.x][mv.set_b.y]=empty;
    return static_cast<int>(total_score*100);
}

int Amazons::compute_hash() const {
    int hash=0;
    for(int i=0;i<8;i++) 
        for(int j=0;j<8;j++) hash=hash*31+Ab[i][j];
    return hash;
}

bool Amazons::if_recompute() const {
    return !cache.computed||compute_hash()!=cache.last_board_hash;
}

void Amazons::compute_d1(int col,int dis_array[8][8]) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
	for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) 
			if(Ab[i][j]==col) {
				q.push(make_tuple(i,j,0));
				vis[i][j]=1;
				dis_array[i][j]=0;
			}
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx,ny=ty;
			for(;;) {
                nx+=bu[dir][0];
                ny+=bu[dir][1];
                
                if(nx<0||nx>7||ny<0||ny>7) break;
                else if(Ab[nx][ny]==barrier) break;
                else if(Ab[nx][ny]!=empty&&Ab[nx][ny]!=col) break;
                
                if(!vis[nx][ny]) {
                    vis[nx][ny]=true;
					dis_array[nx][ny]=d+1;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
}
void Amazons::compute_d2(int col,int dis_array[8][8]) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
	for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) 
			if(Ab[i][j]==col) {
				q.push(make_tuple(i,j,0));
				vis[i][j]=1;
				dis_array[i][j]=0;
			}
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx+bu[dir][0],ny=ty+bu[dir][1];
			if(!(nx<0||nx>7||ny<0||ny>7)&&!vis[nx][ny]) {
				if(Ab[nx][ny]==empty||Ab[nx][ny]==col) {
                    vis[nx][ny]=true;
					dis_array[nx][ny]=d+1;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
}
void Amazons::compute_all_distances() {
    compute_d1(white,cache.queen_to_white);
    compute_d1(black,cache.queen_to_black);
    compute_d2(white,cache.king_to_white);
    compute_d2(black,cache.king_to_black);
    
    cache.computed=1;
    cache.last_board_hash=compute_hash();
    for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) cache.valid[i][j]=1;
}


void Amazons::calc() {
    t1=0.0;
	t2=0.0;
    w=0.0;
	c1=0.0;
    c2=0.0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            if(Ab[i][j]==empty) {
                int d1w=cache.queen_to_white[i][j];
                int d1b=cache.queen_to_black[i][j];
                int d2w=cache.king_to_white[i][j];
                int d2b=cache.king_to_black[i][j];
                
                if(d2w<i_inf&&d2b<i_inf) {
                    double diff=(d2b-d2w)/6.0;
                    diff=max(-1.0,min(1.0,diff));
                    c2+=diff;
                }
				
                if(d1w<i_inf&&d1b<i_inf) {
                    w+=pow(2.0,-abs(d1w-d1b));
                    c1+=pow(2.0,-d1w)-pow(2.0,-d1b);
                }
				
                double delta_wb=0.0;
                if(d1w<d1b) delta_wb=1.0;
                else if(d1w>d1b) delta_wb=-1.0;
                else if(d1w==d1b&&d1w<999) delta_wb=0.1;
                t1+=delta_wb;
				
				if(d2w==i_inf&&d2b==i_inf);
                else if(d2w==d2b) t2+=0.1;
                else if(d2w<d2b) t2+=1.0;
                else t2-=1.0;				
            }
}
int Amazons::queen_distance(int x,int y,int col) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
    q.push(make_tuple(x,y,0));
    vis[x][y]=true;
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        if(Ab[tx][ty]==col) return d;
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx,ny=ty;
			for(;;) {
                nx+=bu[dir][0];
                ny+=bu[dir][1];
                
                if(nx<0||nx>7||ny<0||ny>7) break;
                else if(Ab[nx][ny]==barrier) break;
                else if(Ab[nx][ny]!=empty&&Ab[nx][ny]!=col) break;
                
                if(!vis[nx][ny]) {
                    vis[nx][ny]=true;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
    
    return i_inf;
}
int Amazons::king_distance(int x,int y,int col) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
    q.push(make_tuple(x,y,0));
    vis[x][y]=true;
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        if(Ab[tx][ty]==col) return d;
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx+bu[dir][0],ny=ty+bu[dir][1];
			if(!(nx<0||nx>7||ny<0||ny>7)&&!vis[nx][ny]) {
				if(Ab[nx][ny]==empty||Ab[nx][ny]==col) {
                    vis[nx][ny]=true;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
    
    return i_inf;
}
void Amazons::mark_ray(int x,int y,int dir,bool need_update[8][8]) {
    int nx=x,ny=y;
    for(;;) {
        nx+=bu[dir][0];
        ny+=bu[dir][1];
        if(nx<0||nx>7||ny<0||ny>7||Ab[nx][ny]!=empty) break;
        need_update[nx][ny]=1;
    }
}
void Amazons::mark_affected_positions(const one_move& mv,bool need_update[8][8]) {
    memset(need_update,0,8*8*sizeof(bool));
    need_update[mv.from.x][mv.from.y]=1;
    need_update[mv.to.x][mv.to.y]=1;
    need_update[mv.set_b.x][mv.set_b.y]=1;
    
    for(int dir=0;dir<8;dir++) {
        mark_ray(mv.from.x,mv.from.y,dir,need_update);
        mark_ray(mv.to.x,mv.to.y,dir,need_update);
        mark_ray(mv.set_b.x,mv.set_b.y,dir,need_update);
    }
    
    for(int dir=0;dir<8;dir++) {
        int nx=mv.set_b.x-bu[dir][0];
        int ny=mv.set_b.y-bu[dir][1];
        if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==empty) need_update[nx][ny]=1;
    }
}
void Amazons::update_cache(one_move mv) {
	cache_backup=cache;
    bool need_update[8][8]={0};
    mark_affected_positions(mv,need_update);
    
    swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
    Ab[mv.set_b.x][mv.set_b.y]=barrier;
    
    for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) 
            if(need_update[i][j]&&Ab[i][j]==empty) {
                cache.queen_to_white[i][j]=queen_distance(i,j,white);
                cache.queen_to_black[i][j]=queen_distance(i,j,black);
                cache.king_to_white[i][j]=king_distance(i,j,white);
                cache.king_to_black[i][j]=king_distance(i,j,black);
                cache.valid[i][j]=1;
            }
    cache.last_board_hash=compute_hash();
}

int Amazons::evaluate(one_move mv) {
	
    if(if_recompute()) compute_all_distances();
	
	update_cache(mv);
    calc();
	
    double f1=1.0/(1.0+w);
    double f2=w/(1.0+w);
    double f3=0.5*f2;
	double f4=0.5*f1;
    // v = f1(w)*t1 + f2(w)*c1 + f3(w)*c2 + f4(w)*t2 (P4,Sec2)
    double v=f1*t1+f2*c1+f3*c2+f4*t2;
	
	swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
	Ab[mv.set_b.x][mv.set_b.y]=empty;
    cache=cache_backup;
	
	if(A_side==black) v=-v;
    return static_cast<int>(v*100);
}

const one_move& Amazons::choose_move(int board[8][8],int now_side,vector<one_move> &move_list) {
	memcpy(Ab,board,8*8*sizeof(int));
	A_side=now_side;
	if(if_recompute()) compute_all_distances();
	
	int mx=-i_inf;
	int best_idx=0;
	int cc=0;
	int sz=move_list.size();
	for(auto mv:move_list) {
		int w=(sz>=350?quick_eval(mv):evaluate(mv));
		if(w>mx) {
			mx=w;
			best_idx=cc;
		}
		cc++;
	}
	return move_list[best_idx];
}
/*
g++ -o aaa main.cpp board.cpp step.cpp player.cpp mcts.cpp search.cpp check.cpp cv.cpp Amazons.cpp
*/