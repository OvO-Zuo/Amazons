#include <bits/stdc++.h>
const int black=1;    // 黑子
const int white=-1;   // 白子
const int barrier=2;  // 障碍
const int Empty=0;
const int bu[8][2]={{-1,0},{-1,1},{0,1},{1,1},{1,0},{1,-1},{0,-1},{-1,-1}};
const int black_win=1;
const int white_win=0;
const int not_end=-1;
const int player=1;
const int bot=2;
const int no_lst=250;
const int player_type[4][2]={{1,1},{1,2},{2,1},{2,2}};
//人人，人机，机人，机机
const int i_inf=1e9;
const double inf=100000000000.0;

int rnd();
int game_type;
bool bot_first;
bool if_withdraw;
int Lx=-1,Ly=-1;
double d_inf=1e9;
double eps=1e-1;


int turnID;
//std::mt19937 rnd(chrono::system_clock::now().time_since_epoch().count());
std::mt19937 rng(12345);
int rnd() { 
    return std::abs(static_cast<int>(rng())); 
}

#define GRIDSIZE 8
#define OBSTACLE 2
#define judge_black 0
#define judge_white 1
#define grid_black 1
#define grid_white -1

using namespace std;


//----------------------chess.h-----------------------------//----------------------chess.h-----------------------------
struct pos {
    int x,y;
    pos(int a=0,int b=0):x(a),y(b){}
};
struct one_move {
    pos from;
    pos to;
    pos set_b;
    int now_turn;//黑/白
    one_move(){};
    one_move (const one_move &mv) {
        from.x=mv.from.x;
        from.y=mv.from.y;
        to.x=mv.to.x;
        to.y=mv.to.y;
        set_b.x=mv.set_b.x;
        set_b.y=mv.set_b.y;
        now_turn=mv.now_turn;
    }
    void operator=(const one_move &mv) {
        from.x=mv.from.x;
        from.y=mv.from.y;
        to.x=mv.to.x;
        to.y=mv.to.y;
        set_b.x=mv.set_b.x;
        set_b.y=mv.set_b.y;
        now_turn=mv.now_turn;
    }
};
//---------------------------------------------------

//-------------------step.cpp------------------------
class game_step {
public:
    game_step(){};
   // ~game_step();
    int create_new_step(int board[8][8],int side,std::vector<one_move> &move_list);
    int check_game(int board[8][8],int side);
private:
    void create_barrier(int fx,int fy,int tx,int ty,int side,std::vector<one_move> &move_list);
    one_move best_move;
    bool to_be_search;//是否可以继续搜索
    int nboard[8][8];
    int node_num;// 节点个数
};
int game_step::create_new_step(int board[8][8],int side,
	std::vector<one_move> &move_list) {
	memcpy(nboard,board,8*8*sizeof(int));
	node_num=0;
	int i,j,k,l,t;
	for(i=0;i<8;i++) 
		for(j=0;j<8;j++) 
			if(board[i][j]==side) {
				for(t=0;t<8;t++) {
					k=i+bu[t][0];
					l=j+bu[t][1];
					for(;k>=0&&k<8&&l>=0&&l<8&&board[k][l]==Empty;) {
						create_barrier(i,j,k,l,side,move_list);
						k+=bu[t][0];
						l+=bu[t][1];
					}
				}
			}
	//cout<<move_list.size()<<endl;
	/*for(auto mv:move_list) {
		cout<<"mvv:"<<mv.set_b.x<<" "<<mv.set_b.y<<endl;
	}*/
	return node_num;
}
int game_step::check_game(int board[8][8],int side) {
	int num_b=0,num_w=0;// 不能动的黑/白棋数目
	int i,j,k,l,t;
	int cnt=0;//八个方向堵死的个数
	for(i=0;i<8;i++) 
		for(j=0;j<8;j++) 
			if(board[i][j]&&board[i][j]!=barrier) {
				cnt=0;
				for(t=0;t<8;t++) {
					k=i+bu[t][0];
					l=j+bu[t][1];
					if(k<0||k>=8||l<0||l>=8||board[k][l]) ++cnt;
				}
				if(cnt==8) board[i][j]==black?num_b++:num_w++;
				
			}
	if(side==black&&num_w==4) return black_win;
	else if(side==white&&num_b==4) return white_win;
	else return not_end;
}
void game_step::create_barrier(int fx,int fy,int tx,int ty,
	int side,std::vector<one_move> &move_list) {
	nboard[fx][fy]=0;
	nboard[tx][ty]=side;
	int nx=tx,ny=ty;
	int i;
	for(i=0;i<8;i++) {
		nx=tx+bu[i][0];
		ny=ty+bu[i][1];
		for(;nx>=0&&nx<8&&ny>=0&&ny<8&&nboard[nx][ny]==Empty;) {
			one_move tmp;
			tmp.from=pos(fx,fy);
			tmp.to=pos(tx,ty);
			tmp.set_b=pos(nx,ny);
			tmp.now_turn=side;
			move_list.emplace_back(tmp);
			nx+=bu[i][0];
			ny+=bu[i][1];
			++node_num;
		}
	}
	//cout<<move_list.size()<<endl;
	/*for(auto mv:move_list) {
		cout<<"mvvc:"<<mv.set_b.x<<" "<<mv.set_b.y<<endl;
	}*/
	nboard[fx][fy]=side;
	nboard[tx][ty]=0;
}

//---------------------------------------------------

//-------------------treenode.h--------------------------------

struct tree_node {
    weak_ptr<tree_node> fa_node;                     // 父节点
    vector<shared_ptr<tree_node>> child_node;  // 孩子结点
    vector<one_move> not_use_node;      // 未访问的结点
    int A[8][8];               // 当前局面
    double Qsa;             // 评估分数
    double eval;            // 评估值
    double pu;//先验概率
    int leaf_value;//叶子结点的值
    int now_turn;               // 当前的走子方 
    bool full_expanded;  // 完全展开否
    int num_visit;             // 访问的次数
    double nc;          // 扩展的常数

    tree_node(std::shared_ptr<tree_node>fa,int board[8][8],int side=0,double n_c=sqrt(2)) {
        fa_node=fa;
        memcpy(A,board,8*8*sizeof(int)); 
        eval=inf;   // 未被搜索过的节点评估值inf
        pu=0.0;
        leaf_value=0;
        now_turn=side;
        num_visit=1; 
        full_expanded=false;
        nc=n_c;
    }
    bool operator<(const tree_node &a) const{
        return eval<a.eval;
    }
};
//---------------------------------------------------

//-------------------search.cpp------------------------

class search {
public:
    search();
    virtual ~search();
    void pre_init(int board[8][8]);
    void init(){node_num=0;}
protected:
    void make_move(int board[8][8],const one_move &mv);
    void withdraw_move(int board[8][8],const one_move &mv);
    int check_state(int board[8][8]);

    int A[8][8];
    bool if_search;
    long long node_num;
    game_step *step_creator;
    one_move best_move;

};


search::search()
{
    step_creator=new game_step;
    node_num=0;
    memset(A,0,sizeof(A));
	A[0][2]=black;
	A[2][0]=black;
	A[0][5]=black;
	A[2][7]=black;
	A[5][0]=white;
	A[7][2]=white;
	A[5][7]=white;
	A[7][5]=white;
}
void search::pre_init(int board[8][8]) {
	memcpy(A,board,8*8*sizeof(int));
}
search::~search(){
    if(step_creator!=nullptr){
        delete step_creator;
        step_creator = nullptr;
    }
}

void search::make_move(int board[8][8],const one_move& mv){
    board[mv.from.x][mv.from.y]=Empty;
    board[mv.to.x][mv.to.y]=mv.now_turn;
    board[mv.set_b.x][mv.set_b.y]=barrier;
}

void search::withdraw_move(int board[8][8],const one_move& mv){
    board[mv.set_b.x][mv.set_b.y]=Empty;
    board[mv.to.x][mv.to.y]=Empty;
    board[mv.from.x][mv.from.y]=mv.now_turn;
}

int search::check_state(int board[8][8]) {
    int num_b=0,num_w=0;
    for(int i=0;i<8;++i)
        for(int j=0;j<8;++j)
            if(board[i][j]==black||board[i][j]==white) {
                int cc=0;
                for(int k=0;k<8;++k) {
                    int nx=i+bu[k][0],ny=j+bu[k][1];
                    if(nx<0||nx>7||ny<0||ny>7||board[nx][ny]!=0) ++cc;
                }
                if(cc>=8) {  
                    if(board[i][j]==black) ++num_b;
                    else ++num_w;
                }
            }
	//std::cout<<num_b<<" "<<num_w<<"\n";	
    if(num_b>=4) return white;
    else if(num_w>=4) return black;
    else return 0;
}
//---------------------------------------------------


//---------------------Amazons.cpp------------------------------
struct dis_cache {
    int queen_to_white[8][8];  // 皇后距离到白棋
    int queen_to_black[8][8];  // 皇后距离到黑棋
    int king_to_white[8][8];   // 国王距离到白棋
    int king_to_black[8][8];   // 国王距离到黑棋
    
    bool valid[8][8];
    bool computed;
    int last_board_hash;
    
    dis_cache():computed(false),last_board_hash(0) {
        memset(queen_to_white,0x3f,8*8*sizeof(int));
        memset(queen_to_black,0x3f,8*8*sizeof(int));
        memset(king_to_white,0x3f,8*8*sizeof(int));
        memset(king_to_black,0x3f,8*8*sizeof(int));
        memset(valid,0,8*8*sizeof(bool));
    }
    
    void reset() {
        memset(queen_to_white,0x3f,8*8*sizeof(int));
        memset(queen_to_black,0x3f,8*8*sizeof(int));
        memset(king_to_white,0x3f,8*8*sizeof(int));
        memset(king_to_black,0x3f,8*8*sizeof(int));
        memset(valid,0,8*8*sizeof(bool));
        computed=false;
    }
};

class Amazons {
public:
    const one_move& choose_move(int board[8][8],int side,std::vector<one_move> &move_list);
protected:
    int Ab[8][8];
    int A_side;
    double w,c1,c2,t1,t2;
    dis_cache cache;
    
    struct move_cache {
        one_move move;
        int v;
        bool end_eval;//evaluated;
    };
    int quick_eval(one_move mv);
    void update_cache(one_move mv);
    int queen_distance(int x,int y,int col);
    int king_distance(int x,int y,int col);
    void mark_affected_positions(const one_move& mv, bool needs_update[8][8]);
    void mark_ray(int x, int y, int dir, bool needs_update[8][8]);
    void calc();                          
    void compute_all_distances();         
    void compute_d1(int col,int dis_array[8][8]);
    void compute_d2(int col,int dis_array[8][8]);
    int evaluate(one_move mv);  
    
    int compute_hash() const;
    bool if_recompute() const;
    
private:
    dis_cache cache_backup;
};

int Amazons::quick_eval(one_move mv) {
	swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
	Ab[mv.set_b.x][mv.set_b.y]=barrier;

    double total_score=0.0;
    int tdis=max(abs(2*mv.to.x-7),abs(2*mv.to.y-7));
    double center_score=(14.0-tdis)*0.1;
    bool is_in_corner=(mv.to.x<=1&&mv.to.y<=1)||(mv.to.x<=1&&mv.to.y>=6)||
                      (mv.to.x>=6&&mv.to.y<=1)||(mv.to.x>=6&&mv.to.y>=6);
    if(is_in_corner) center_score-=1.5;
    total_score+=center_score;
    
    int mobility=0;
    for(int dir=0;dir<8;dir++) {
        int nx=mv.to.x+bu[dir][0];
        int ny=mv.to.y+bu[dir][1];
        if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==Empty) mobility++;
    }
    
    double mobility_score=0.0;
    if(mobility<=2) mobility_score=-3.0; 
    else if(mobility<=4) mobility_score=-1.0;
    else if (mobility >= 6) mobility_score=1.5;
    total_score+=mobility_score;
    
    double arrow_score=0.0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++) 
            if(Ab[i][j]==(A_side==black?white:black)) {
                int q_dis=max(abs(mv.set_b.x-i),abs(mv.set_b.y-j));
                if(q_dis<=2) arrow_score+=(3-q_dis)*0.4;
            }
    int make_link=0;
    for(int dir=0;dir<8;dir++) {
        int nx=mv.set_b.x+bu[dir][0];
        int ny=mv.set_b.y+bu[dir][1];
        if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==barrier) make_link++;
    }
    if(make_link>=2) arrow_score+=1.5;
    total_score+=arrow_score;
    
    int move_dis=max(abs(mv.to.x-mv.from.x),abs(mv.to.y-mv.from.y));
    double move_dis_score=0.0;
    if (move_dis==1) move_dis_score=-0.5;
    else if(move_dis>=2&&move_dis<=4) move_dis_score=1.0;
    else if(move_dis>=5) move_dis_score=0.5;
    total_score+=move_dis_score;
    
    double distribute_score=0.0;
    int avg_dis=0.0;
    for(int i=0;i<8;i++) 
        for(int j=0;j<8;j++) {
            if(Ab[i][j]==A_side&&!(i==mv.from.x&&j==mv.from.y)) {
                int dist=max(abs(mv.to.x-i),abs(mv.to.y-j));
                avg_dis+=dist;
            }
        }
    
    if(avg_dis<10) distribute_score=-1.0;
    else if(avg_dis>15) distribute_score=0.5;
    total_score+=distribute_score;
    
    double defense_score=0.0;
    for(int i=0;i<8;i++) 
        for(int j=0;j<8;j++) 
            if(Ab[i][j]==A_side&&!(i==mv.from.x&&j==mv.from.y)) {
                int num=0;
                for(int dir=0;dir<8;dir++) {
                    int nx=i+bu[dir][0];
                    int ny=j+bu[dir][1];
                    if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==Empty) num++;
                }
                if(num<=2) defense_score-=2.0;
            }    
    total_score+=defense_score;
    
    int num_empty=0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            if(Ab[i][j]==Empty) num_empty++;
    
    double endgame_factor=0.0;
    if(num_empty<24) {
        double territory_score=0.0;
        int my_near_bar=0;
        int oppo_near_bar=0;
        for(int dir=0;dir<8;dir++) {
            int nx=mv.set_b.x+bu[dir][0];
            int ny=mv.set_b.y+bu[dir][1];
            if(nx>=0&&nx<8&&ny>=0&&ny<8) {
                if(Ab[nx][ny]==A_side) my_near_bar++;
                else if(Ab[nx][ny]!=Empty&&Ab[nx][ny]!=barrier) oppo_near_bar++;
            }
        }
        if(my_near_bar>oppo_near_bar) territory_score=0.8;
        else if(my_near_bar<oppo_near_bar) territory_score=-0.5;        
        endgame_factor=territory_score*(32-num_empty)/10.0;
    }
    total_score+=endgame_factor;
	
	swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
	Ab[mv.set_b.x][mv.set_b.y]=Empty;
    return static_cast<int>(total_score*100);
}
int Amazons::compute_hash() const {
    int hash=0;
    for(int i=0;i<8;i++) 
        for(int j=0;j<8;j++) hash=hash*31+Ab[i][j];
    return hash;
}

bool Amazons::if_recompute() const {
    return !cache.computed||compute_hash()!=cache.last_board_hash;
}

void Amazons::compute_d1(int col,int dis_array[8][8]) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
	for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) 
			if(Ab[i][j]==col) {
				q.push(make_tuple(i,j,0));
				vis[i][j]=1;
				dis_array[i][j]=0;
			}
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx,ny=ty;
			for(;;) {
                nx+=bu[dir][0];
                ny+=bu[dir][1];
                
                if(nx<0||nx>7||ny<0||ny>7) break;
                else if(Ab[nx][ny]==barrier) break;
                else if(Ab[nx][ny]!=Empty&&Ab[nx][ny]!=col) break;
                
                if(!vis[nx][ny]) {
                    vis[nx][ny]=true;
					dis_array[nx][ny]=d+1;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
}
void Amazons::compute_d2(int col,int dis_array[8][8]) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
	for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) 
			if(Ab[i][j]==col) {
				q.push(make_tuple(i,j,0));
				vis[i][j]=1;
				dis_array[i][j]=0;
			}
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx+bu[dir][0],ny=ty+bu[dir][1];
			if(!(nx<0||nx>7||ny<0||ny>7)&&!vis[nx][ny]) {
				if(Ab[nx][ny]==Empty||Ab[nx][ny]==col) {
                    vis[nx][ny]=true;
					dis_array[nx][ny]=d+1;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
}
void Amazons::compute_all_distances() {
    compute_d1(white,cache.queen_to_white);
    compute_d1(black,cache.queen_to_black);
    compute_d2(white,cache.king_to_white);
    compute_d2(black,cache.king_to_black);
    
    cache.computed=1;
    cache.last_board_hash=compute_hash();
    for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) cache.valid[i][j]=1;
}


void Amazons::calc() {
    t1=0.0;
	t2=0.0;
    w=0.0;
	c1=0.0;
    c2=0.0;
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            if(Ab[i][j]==Empty) {
                int d1w=cache.queen_to_white[i][j];
                int d1b=cache.queen_to_black[i][j];
                int d2w=cache.king_to_white[i][j];
                int d2b=cache.king_to_black[i][j];
                
                if(d2w<i_inf&&d2b<i_inf) {
                    double diff=(d2b-d2w)/6.0;
                    diff=max(-1.0,min(1.0,diff));
                    c2+=diff;
                }
				
                if(d1w<i_inf&&d1b<i_inf) {
                    w+=pow(2.0,-abs(d1w-d1b));
                    c1+=pow(2.0,-d1w)-pow(2.0,-d1b);
                }
				
                double delta_wb=0.0;
                if(d1w<d1b) delta_wb=1.0;
                else if(d1w>d1b) delta_wb=-1.0;
                else if(d1w==d1b&&d1w<999) delta_wb=0.1;
                t1+=delta_wb;
				
				if(d2w==i_inf&&d2b==i_inf);
                else if(d2w==d2b) t2+=0.1;
                else if(d2w<d2b) t2+=1.0;
                else t2-=1.0;				
            }
}
int Amazons::queen_distance(int x,int y,int col) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
    q.push(make_tuple(x,y,0));
    vis[x][y]=true;
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        if(Ab[tx][ty]==col) return d;
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx,ny=ty;
			for(;;) {
                nx+=bu[dir][0];
                ny+=bu[dir][1];
                
                if(nx<0||nx>7||ny<0||ny>7) break;
                else if(Ab[nx][ny]==barrier) break;
                else if(Ab[nx][ny]!=Empty&&Ab[nx][ny]!=col) break;
                
                if(!vis[nx][ny]) {
                    vis[nx][ny]=true;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
    
    return i_inf;
}
int Amazons::king_distance(int x,int y,int col) {
    bool vis[8][8]={0};
    queue<tuple<int,int,int>> q;
    
    q.push(make_tuple(x,y,0));
    vis[x][y]=true;
    
    for(;!q.empty();) {
        int tx=get<0>(q.front());
		int ty=get<1>(q.front());
		int d=get<2>(q.front());
        q.pop();
        if(Ab[tx][ty]==col) return d;
        
        for(int dir=0;dir<8;dir++) {
            int nx=tx+bu[dir][0],ny=ty+bu[dir][1];
			if(!(nx<0||nx>7||ny<0||ny>7)&&!vis[nx][ny]) {
				if(Ab[nx][ny]==Empty||Ab[nx][ny]==col) {
                    vis[nx][ny]=true;
                    q.push(make_tuple(nx,ny,d+1));
                }
            }
        }
    }
    
    return i_inf;
}
void Amazons::mark_ray(int x,int y,int dir,bool need_update[8][8]) {
    int nx=x,ny=y;
    for(;;) {
        nx+=bu[dir][0];
        ny+=bu[dir][1];
        if(nx<0||nx>7||ny<0||ny>7||Ab[nx][ny]!=Empty) break;
        need_update[nx][ny]=1;
    }
}
void Amazons::mark_affected_positions(const one_move& mv,bool need_update[8][8]) {
    memset(need_update,0,8*8*sizeof(bool));
    need_update[mv.from.x][mv.from.y]=1;
    need_update[mv.to.x][mv.to.y]=1;
    need_update[mv.set_b.x][mv.set_b.y]=1;
    
    for(int dir=0;dir<8;dir++) {
        mark_ray(mv.from.x,mv.from.y,dir,need_update);
        mark_ray(mv.to.x,mv.to.y,dir,need_update);
        mark_ray(mv.set_b.x,mv.set_b.y,dir,need_update);
    }
    
    for(int dir=0;dir<8;dir++) {
        int nx=mv.set_b.x-bu[dir][0];
        int ny=mv.set_b.y-bu[dir][1];
        if(nx>=0&&nx<8&&ny>=0&&ny<8&&Ab[nx][ny]==Empty) need_update[nx][ny]=1;
    }
}
void Amazons::update_cache(one_move mv) {
	cache_backup=cache;
    bool need_update[8][8]={0};
    mark_affected_positions(mv,need_update);
    
    swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
    Ab[mv.set_b.x][mv.set_b.y]=barrier;
    
    for(int i=0;i<8;i++)
		for(int j=0;j<8;j++) 
            if(need_update[i][j]&&Ab[i][j]==Empty) {
                cache.queen_to_white[i][j]=queen_distance(i,j,white);
                cache.queen_to_black[i][j]=queen_distance(i,j,black);
                cache.king_to_white[i][j]=king_distance(i,j,white);
                cache.king_to_black[i][j]=king_distance(i,j,black);
                cache.valid[i][j]=1;
            }
    cache.last_board_hash=compute_hash();
}

int Amazons::evaluate(one_move mv) {
	
    if(if_recompute()) compute_all_distances();
	
	update_cache(mv);
    calc();
	
    double f1=1.0/(1.0+w);
    double f2=w/(1.0+w);
    double f3=0.5*f2;
	double f4=0.5*f1;
    // v = f1(w)*t1 + f2(w)*c1 + f3(w)*c2 + f4(w)*t2 (P4,Sec2)
	if(turnID<=3) t1*=3,t2*=2;
    double v=f1*t1+f2*c1+f3*c2+f4*t2;
	
	swap(Ab[mv.from.x][mv.from.y],Ab[mv.to.x][mv.to.y]);
	Ab[mv.set_b.x][mv.set_b.y]=Empty;
    cache=cache_backup;
	
	if(A_side==black) v=-v;
    return static_cast<int>(v*100);
}

const one_move& Amazons::choose_move(int board[8][8],int now_side,vector<one_move> &move_list) {
	memcpy(Ab,board,8*8*sizeof(int));
	A_side=now_side;
	if(if_recompute()) compute_all_distances();
	
	int mx=-i_inf;
	int best_idx=0;
	int cc=0;
	int sz=move_list.size();
	//cout<<sz<<endl;
	for(auto mv:move_list) {
		int w=(sz>=500?quick_eval(mv):evaluate(mv));
		if(w>mx) {
			mx=w;
			best_idx=cc;
		}
		cc++;
	}
	//one_move tmp=move_list[best_idx];
	//cout<<tmp.from.x<<" "<<tmp.from.y<<" "<<tmp.to.x<<" "<<tmp.to.y<<" "<<tmp.set_b.x<<" "<<tmp.set_b.y<<endl;
	return move_list[best_idx];
}

//---------------------------------------------------

//--------------------mcts.cpp-------------------------------
class MCT:public search,public Amazons {
public:
    MCT(double limit_c=sqrt(2));
    virtual ~MCT()=default;
    one_move MCT_search(const one_move& mv,int now_col);//GetBestMove
private:
    double time_limit; //搜索时间限制
    double n_const;// 扩展常数
    std::shared_ptr<tree_node> rt;
    one_move move_from_fa; // m_move
    time_t start_time;
    time_t end_time;

    std::shared_ptr<tree_node>& best_child(std::shared_ptr<tree_node> &node);//返回最佳孩子
    std::shared_ptr<tree_node> tree_policy(std::shared_ptr<tree_node> node);//返回最佳叶子或未经扩展的叶子
    int default_policy(std::shared_ptr<tree_node> node); //rollout
    void backtrack(std::shared_ptr<tree_node> &node,int leaf_value);//负极大 回溯 

};

MCT::MCT(double c) {
    n_const=c;
    time_limit=0.85;   
    if_search=true;
}

one_move MCT::MCT_search(const one_move& mv,int now_col) {
    move_from_fa=mv;
    if(mv.now_turn!=no_lst) {
        make_move(A,mv); 
    }
    
    rt=std::make_shared<tree_node>(nullptr,A,now_col,n_const);
    
    decltype(rt) best_son;
    time(&start_time);
    int iterations = 0;
    for(;if_search;) {
        iterations++;
        auto leaf=tree_policy(rt);
        int value=default_policy(leaf);
        backtrack(leaf,value);

        time(&end_time);
        if(difftime(end_time,start_time)>time_limit) break;
    }

    best_son=best_child(rt);
    
    for(int i=0;i<8;++i)
        for(int j=0;j<8;++j) {
            if(A[i][j]!=barrier&&best_son->A[i][j]==barrier) 
                best_move.set_b.x=i,best_move.set_b.y=j;
            if(A[i][j]!=now_col&&best_son->A[i][j]==now_col)
                best_move.to.x=i,best_move.to.y=j;
            if(A[i][j]==now_col&&best_son->A[i][j]!=now_col)
                best_move.from.x=i,best_move.from.y=j;
        }
    
    rt.reset(); 
    best_move.now_turn=now_col;
    make_move(A,best_move);
    return best_move;
}

std::shared_ptr<tree_node>& MCT::best_child(std::shared_ptr<tree_node>&node) {
    if(node->child_node.empty()) return node;
    int mx=0;
    int len=node->child_node.size();
    for(int i=0;i<len;++i) {
        if((node->child_node[i]->eval)>(node->child_node[mx]->eval)) mx=i;
    }
    return node->child_node[mx];
}

std::shared_ptr<tree_node> MCT::tree_policy(std::shared_ptr<tree_node> node) {
    for(;check_state(node->A)==0;) {
        (node->num_visit)++;  
        if(!(node->not_use_node.empty())) {
            int len=(node->not_use_node).size();
            int idx=rnd()%len;
            one_move mv=node->not_use_node[idx];
            node->not_use_node.erase(node->not_use_node.begin()+idx); 
            
            make_move(node->A,mv);
            auto child=std::make_shared<tree_node>(node,node->A,-(node->now_turn),node->nc);
            withdraw_move(node->A,mv);
            node->child_node.emplace_back(child);
            ++node_num;  
            if(node->not_use_node.empty()) node->full_expanded=true;
            return child;
        } else if(node->child_node.empty()) {
            int num=step_creator->create_new_step(node->A,node->now_turn,node->not_use_node);
            if(num==0) { 
                node->full_expanded=true;  
                break;
            }
        } else {
            bool all_expanded=true;
            for(const auto &child:node->child_node) {
                if(!child->full_expanded) {
                    all_expanded=false;
                    break;
                }
            }
            if(all_expanded) {  
                node->full_expanded=true;
                return node;
            }
            node=best_child(node);
        }
    }
    return node;
}

int MCT::default_policy(std::shared_ptr<tree_node> node) {
    if(node->full_expanded) return node->leaf_value;
    
    int board[8][8];
    memcpy(board,node->A,8*8*sizeof(int));
    
    std::vector<one_move> move_list;
    int res=check_state(board);
    if(res) {
        node->full_expanded=true;
        return res;
    }
    
    int side=node->now_turn;
    int now_depth=0;
    int max_depth=50;
    
    for(;res==Empty&&now_depth<max_depth;) {
        step_creator->create_new_step(board,side,move_list);
        if(move_list.empty()) break;
        
        const one_move& mv=choose_move(board,side,move_list);
        make_move(board,mv);
        
        res=check_state(board);
        side=-side;
        move_list.clear();
        now_depth++;
    }
    
    if(res==Empty&&now_depth>=max_depth) {
        int my_num=0,oppo_num=0;
        for(int i=0;i<8;i++) 
            for(int j=0;j<8;j++) {
                if(board[i][j]==node->now_turn) {
                    bool can_move=false;
                    for(int dir=0;dir<8;dir++) {
                        int nx=i+bu[dir][0];
                        int ny=j+bu[dir][1];
                        if(nx>=0&&nx<8&&ny>=0&&ny<8&&board[nx][ny]==Empty) {
                            can_move=true;
                            break;
                        }
                    }
                    if(can_move) my_num++;
                } else if(board[i][j]==-(node->now_turn)) {
                    bool can_move=false;
                    for(int dir=0;dir<8;dir++) {
                        int nx=i+bu[dir][0];
                        int ny=j+bu[dir][1];
                        if(nx>=0&&nx<8&&ny>=0&&ny<8&&board[nx][ny]==Empty) {
                            can_move=true;
                            break;
                        }
                    }
                    if(can_move) oppo_num++;
                }
            }        
        if(my_num==0) res=-(node->now_turn);
        else if(oppo_num==0) res=node->now_turn;
        else res = 0;
    }    
    return res;
}

void MCT::backtrack(std::shared_ptr<tree_node>&node,int leaf_value) {
    node->num_visit++;
    double now_v;
    if(leaf_value==0) now_v=0.0;
    else if((node->now_turn==leaf_value&&leaf_value)) now_v=1.0;
    else now_v=-1.0;
    node->Qsa=((node->num_visit-1)*node->Qsa+now_v)/node->num_visit;
    if(node->fa_node.lock()!=nullptr) {
        int fn=node->fa_node.lock()->num_visit;
        int n=node->num_visit;
        node->pu=node->nc*sqrt(log(fn+1e-8)/(n+1e-8));
        node->eval=node->Qsa+node->pu;
    } else node->eval=node->Qsa;   
    node->leaf_value = leaf_value;
    if(node->fa_node.lock()!=nullptr) {
		auto parent=node->fa_node.lock();
		backtrack(parent,-leaf_value);
	}
}
//---------------------------------------------------




int currBotColor; // 我所执子颜色（1为黑，-1为白，棋盘状态亦同）
int gridInfo[GRIDSIZE][GRIDSIZE] = { 0 }; // 先x后y，记录棋盘状态
int dx[] = { -1,-1,-1,0,0,1,1,1 };
int dy[] = { -1,0,1,-1,1,-1,0,1 };

// 判断是否在地图内
inline bool inMap(int x, int y)
{
	if (x < 0 || x >= GRIDSIZE || y < 0 || y >= GRIDSIZE)
		return false;
	return true;
}


// 在坐标处落子，检查是否合法或模拟落子
bool ProcStep(int x0, int y0, int x1, int y1, int x2, int y2, int color, bool check_only)
{
	if ((!inMap(x0, y0)) || (!inMap(x1, y1)) || (!inMap(x2, y2)))
		return false;
	if (gridInfo[x0][y0] != color || gridInfo[x1][y1] != 0)
		return false;
	if ((gridInfo[x2][y2] != 0) && !(x2 == x0 && y2 == y0))
		return false;
	if (!check_only)
	{
		gridInfo[x0][y0] = 0;
		gridInfo[x1][y1] = color;
		gridInfo[x2][y2] = OBSTACLE;
	}
	return true;
}
int main()
{
	int x0, y0, x1, y1, x2, y2;

	// 初始化棋盘
	gridInfo[0][(GRIDSIZE - 1) / 3] = gridInfo[(GRIDSIZE - 1) / 3][0]
		= gridInfo[GRIDSIZE - 1 - ((GRIDSIZE - 1) / 3)][0]
		= gridInfo[GRIDSIZE - 1][(GRIDSIZE - 1) / 3] = grid_black;
	gridInfo[0][GRIDSIZE - 1 - ((GRIDSIZE - 1) / 3)] = gridInfo[(GRIDSIZE - 1) / 3][GRIDSIZE - 1]
		= gridInfo[GRIDSIZE - 1 - ((GRIDSIZE - 1) / 3)][GRIDSIZE - 1]
		= gridInfo[GRIDSIZE - 1][GRIDSIZE - 1 - ((GRIDSIZE - 1) / 3)] = grid_white;

	cin >> turnID;

	// 读入到当前回合为止，自己和对手的所有行动，从而把局面恢复到当前回合
	currBotColor = grid_white; // 先假设自己是白方
	for (int i = 0; i < turnID; i++)
	{
		// 根据这些输入输出逐渐恢复状态到当前回合

		// 首先是对手行动
		cin >> x0 >> y0 >> x1 >> y1 >> x2 >> y2;
		if (x0 == -1)
			currBotColor = grid_black; // 第一回合收到坐标是-1, -1，说明我是黑方
		else
			ProcStep(x0, y0, x1, y1, x2, y2, -currBotColor, false); // 模拟对方落子

		// 然后是自己当时的行动
		// 对手行动总比自己行动多一个
		if (i < turnID - 1)
		{
			cin >> x0 >> y0 >> x1 >> y1 >> x2 >> y2;
			if (x0 >= 0)
				ProcStep(x0, y0, x1, y1, x2, y2, currBotColor, false); // 模拟己方落子
		}
	}

	// 做出决策（你只需修改以下部分）
		
	MCT BOT;
	BOT.pre_init(gridInfo);
	one_move lst;
	lst.now_turn=no_lst;
	lst=BOT.MCT_search(lst,currBotColor);
	// 决策结束，输出结果（你只需修改以上部分）
	cout <<lst.from.x<< ' ' <<lst.from.y<< ' ' <<lst.to.x<< ' ' <<lst.to.y<< ' ' <<lst.set_b.x<< ' ' <<lst.set_b.y<< endl;
	return 0;
}