#ifndef TREENODE_H
#define TREENODE_H

#include <bits/stdc++.h>
#include "chess.h"
#include "cv.h"
using namespace std;

struct tree_node {
    weak_ptr<tree_node> fa_node;                     // 父节点
    vector<shared_ptr<tree_node>> child_node;  // 孩子结点
    vector<one_move> not_use_node;      // 未访问的结点
    int A[8][8];               // 当前局面
    double Qsa;             // 评估分数
    double eval;            // 评估值
    double pu;//先验概率
    int leaf_value;//叶子结点的值
    int now_turn;               // 当前的走子方 
    bool full_expanded;  // 完全展开否
    int num_visit;             // 访问的次数
    double nc;          // 扩展的常数

    tree_node(std::shared_ptr<tree_node>fa,int board[8][8],int side=0,double n_c=sqrt(2)) {
        fa_node=fa;
        memcpy(A,board,8*8*sizeof(int)); 
        eval=inf;   // 未被搜索过的节点评估值inf
        pu=0.0;
        leaf_value=0;
        now_turn=side;
        num_visit=1; 
        full_expanded=false;
        nc=n_c;
    }
    bool operator<(const tree_node &a) const{
        return eval<a.eval;
    }
};

#endif