#ifndef STEP_H
#define STEP_H

#include <vector>
#include "chess.h"
void withdraw(int n_step);
void push_move(int c_x,int c_y,int p_x,int p_y);
void push_set_barrier(int b_x,int b_y);
struct Step {
    int now_turn;//该步走子方
    int now_type;//该步 走棋/放障碍
    int c_x,c_y;//走棋中的起点 / 放障碍中的障碍点
    int p_x,p_y;//走棋中的终点
};
extern std::vector<Step> step_stack; 

class game_step {
public:
    game_step(){};
   // ~game_step();
    int create_new_step(int board[8][8],int side,std::vector<one_move> &move_list);
    int check_game(int board[8][8],int side);
private:
    void create_barrier(int fx,int fy,int tx,int ty,int side,std::vector<one_move> &move_list);
    one_move best_move;
    bool to_be_search;//是否可以继续搜索
    int nboard[8][8];
    int node_num;// 节点个数
};

#endif